Thank you for downloading a Planet Font!

____________________________________________________________________________

This Planet font is a PC TrueType font. It has a full character set in both 
upper- and lower case, full punctuation, most international characters, 
accents etc. and it contains an extensive kerning table.

Currently all of the typefaces in the planet Font Family are CD-Ware and 
free for non-commercial use. That means, for each typeface you want to 
license for commercial use, you must mail us a CD of something you like: 
Music you have made, love or designed the cover for or a multimedia or 
software title...

Such a CD in our mailbox buys you a personal, non-transferable but 
everlasting license to use that typeface for commercial projects. And most 
probably a personal review of the CD from the font designer.

If you like what you did with our fonts, you are more than welcome to send a 
copy, a screenshot or a scan of the product back to us. We are always eager 
to see how people use the fonts, and we're collecting examples for future 
publishing on the web.



____________________________________________________________________________
This Planet Font is copyright � 1996 by Mads Rydahl, All Rights 
Reserved.  It is distributed free, provided all files in this archive 
(including this text ducument) are included.  User groups and 
shareware/public domain outlets may distribute the font under these 
contitions, provided that credit is given next to the font or next to any 
link to the font. This credit shall take the form of a clearly readable text 
stating the name of the designer and a link to The Planet website at 
http://www.planet.dk/. 
____________________________________________________________________________

     T h e   P l a n e t

          multimedia design studio 
____________________________________________________________________________

     Klerkegade 19, 4. 
     DK-1308 Copenhagen K Denmark

     Phone  +45 33 93 00 20 
     Mobile +45 21 79 08 66

     private mail: mailto:mads@planet.dk 
     Company site: http://www.planet.dk 
     Company mail: mailto:beam@planet.dk

____________________________________________________________________________
